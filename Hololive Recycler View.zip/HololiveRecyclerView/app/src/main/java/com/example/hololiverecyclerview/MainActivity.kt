package com.example.hololiverecyclerview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.hololiverecyclerview.adapter.ListMemberAdapter
import com.example.hololiverecyclerview.model.Member

class MainActivity : AppCompatActivity() {
    private lateinit var rvMember: RecyclerView
    private val list = ArrayList<Member>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        rvMember = findViewById(R.id.rv_hololive)
        rvMember.setHasFixedSize(true)

        list.addAll(getListHeroes())
        showRecyclerList()
    }
    private fun getListHeroes(): ArrayList<Member> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataRegion = resources.getStringArray(R.array.data_region)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.getStringArray(R.array.data_photo)
        val listHero = ArrayList<Member>()
        for (i in dataName.indices) {
            val hero = Member(dataName[i], dataRegion[i],dataDescription[i], dataPhoto[i])
            listHero.add(hero)
        }
        return listHero
    }

    private fun showRecyclerList() {
        rvMember.layoutManager = LinearLayoutManager(this)
        val listMemberAdapter = ListMemberAdapter(list)
        rvMember.adapter = listMemberAdapter
    }
}